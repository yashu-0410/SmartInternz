# Prompt engineering utilities
