# Sustainable Smart City Assistant

Project using IBM Granite LLM, Streamlit, and Pinecone.
