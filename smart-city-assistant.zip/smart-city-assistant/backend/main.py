# Entry point for FastAPI backend
