# Pinecone integration script
