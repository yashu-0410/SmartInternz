# Dummy forecasting model
