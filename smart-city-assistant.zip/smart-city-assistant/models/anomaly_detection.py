# Dummy anomaly detection model
